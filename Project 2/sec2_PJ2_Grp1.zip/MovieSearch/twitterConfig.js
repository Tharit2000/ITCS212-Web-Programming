//call it config.js because it's a configuration of my twitter
//You can store code you want to reference 
//in another separate file

//Like a mini package.
// This file I am going to put API keys
module.exports= {
    consumer_key:         '9TDYP1Z2qTEtKO68oy5KpJ2v9'
    ,consumer_secret:      'fBl5ymHso8HH7yU2E0RjGkaOeGyjQx9A61GxlCtTeJ3Iciuje4'
    ,access_token:         '3189926455-dcVQ4NOkfcFbtUgVz3mUmHVJO2MPcJTkZnBXuyQ'
    ,access_token_secret:  'MoLo9llxH3i49IBLPIndnjtkKFhzwMX1XRelH0EontY1G'
}

/*
    Twitter ID password
    email: worameth.jojo@gmail.com
    password: abcd123456789
*/