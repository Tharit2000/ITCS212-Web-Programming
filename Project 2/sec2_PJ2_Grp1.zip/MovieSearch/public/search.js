function search() {
  // Get value from our input tag
  let inputQuery = document.getElementById("query").value;
  console.log(inputQuery);
  omdbSearch(inputQuery);
  youtubeSearch(inputQuery);
  spotifySearch(inputQuery);
  twitterSearch(inputQuery);
}

function omdbSearch(inputQuery) {
  // clear omdb output
  $('#omdb').html("");
  console.log("OMDbSearch is activated")

  $(document).ready(function () {
    // do a HTTP get request through omdbapi
    $.get(
      "http://www.omdbapi.com/",
      {
        apikey: "9ba1bfdc",
        t: inputQuery,
        r: "json",
      },
      // *************************** //
      //A callback function for handling the data we get from our get request
      function (data) {
        console.log(data);
        let output = "";
        // try to build html-like syntax string and append to output
        output += '<img class="card-img-top my3" src="' + data.Poster + '">'
                + '<div class="card-body">'
                  + '<h4 class="card-title">' + data.Title + '</h4>'
                  + '<p class="card-text">'
                  + '<b>Released: </b>' + data.Released + '<br>'
                  + '<b>Type: </b>' + data.Type + '<br>'
                  + '<b>Runtime: </b>' + data.Runtime + '<br>'
                  + '<b>Genre: </b>' + data.Genre + '<br>'
                  + '<b>Actors: </b>' + data.Actors + '<br>'
                  + '<b>Plot: </b>' + data.Plot + '<br>'
                  + '<b>Language: </b>' + data.Language + '<br>'
                  + '<b>Ratings: </b>' + data.Ratings[0].Value + '<br>'
                + '</div>';
        // turn output into html
        $("#omdb").html(output);
      }
    );
  });
}

function youtubeSearch(inputQuery) {
  // clear youtube output
  $('#youtube').html('');

  // receive user query parameter
  q = inputQuery + " trailer";

  // insert parameters and get data
  $.get(
    "http://localhost:3000/youtube", {
      q: q,       
    }, function(item) {
      console.log("YoutubeSearched is activated")
      // get output
      let output = '<img class="card-img-top my3" src="' + item.snippet.thumbnails.high.url + '">'
                    + '<div class="card-body">' 
                      + '<h4 class="card-title">' + item.snippet.title + '</h4>' 
                      + '<p class="card-text"> URL: <a target="_blank" href="https://www.youtube.com/embed/' + item.id.videoId + '">https://www.youtube.com/embed/' + item.id.videoId + '</a></p>';
                    + '</div>';
      // turn output into html
      $('#youtube').html(output);
    }
  )
}

function spotifySearch(inputQuery) {
  // clear spotify output
  $("#spotify").html("");
  console.log("SpotifySearch is activated")
  // get data from the app.js
  $.get("http://localhost:3000/spotify", {
    q: inputQuery,
  }, function (data) {
    console.log(data);
    // manipulate data and turn to html-like string
    let output = "";
    output += '<iframe src="https://open.spotify.com/embed/playlist/' + data.playlists.items[0].id + '" width="100%" height="380" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>';
    // turn output to html 
    $('#spotify').html(output);
  });
}


function twitterSearch(inputQuery) {
  // clear twitter output
  $("#twitter").html("");

  console.log("TwitterSearch is activated")
  // Call to this route to get data from app.js
  $.get("http://localhost:3000/twitter", {
    q: inputQuery,
  }, function (data) {
    console.log(data)


    let output = "";
    // from callback function(data) 
    // we run each loop through data to build html-like string
    $.each(data.statuses, function (i, tweet) {
      console.log(tweet);
      output += '<div class="m-0">'
        + '<blockquote class="twitter-tweet">'
        + '<a href="https://twitter.com/' + tweet.user.screen_name + '/status/' + tweet.id_str + '?ref src=twsrc%5Etfw"></a>'
        + '</blockquote>'
        + '</div>';
    });
    // turn output into html
    $('#twitter').html(output);
    // refresh screeen
    twttr.widgets.load();
  });
}